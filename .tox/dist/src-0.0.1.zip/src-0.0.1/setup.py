from setuptools import setup, find_packages
# find_packages will find all the packages

setup(
    name="src",
    version = "0.0.1",
    description = "its a wine 0 package",
    author = "akash",
    packages = find_packages(),
    license = "MIT"
)